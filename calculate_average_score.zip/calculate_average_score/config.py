APP_ID = '17868961'  # 对应替换为你申请的AppID
API_KEY = 'sZGw4ynaOLIdXoijfI5IFbYX'  # 对应替换为你申请的API Key
SECRET_KEY = '98q8NEoKTWioZzv8Bey7HOEYgiYTDL8I' # 对应替换为你申请的Secret Key
user_id = '2017115026' # 对应写入你自己的教务账号
user_password = 'cy991127' # 对应写入你自己的教务密码
user_major='物流工程'#对应写入你的专业：安全工程，交通工程，交通运输，交通运输(城市轨道交通)，交通运输(詹天佑学院)，物流工程，物流管理