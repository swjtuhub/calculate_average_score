自动化计算保研分数
===
涉及到的库  
`baidu-aip lxml openpyxl Pillow psycopg2 requests selenium xlrd pandas` 

> python版本 最低为3.6

安装包
`pip install baidu-aip lxml openpyxl Pillow requests xlrd`
> 除`baidu-aip`之外的所有包都可用`conda`或`pip`安装
进入[百度ai开放平台](http://ai.baidu.com/)  
点击控制台 登录 选择左侧文字识别 然后创建应用  
应用的名字和简介随便写，常见成功后会显示`AppID API Key Secret Key`
在该目录下创建`config.py`
---
配置文件：
`config.py`
```
APP_ID = '17868961'  # 对应替换为你申请的AppID
API_KEY = 'sZGw4ynaOLIdXoijfI5IFbYX'  # 对应替换为你申请的API Key
SECRET_KEY = '98q8NEoKTWioZzv8Bey7HOEYgiYTDL8I' # 对应替换为你申请的Secret Key
user_id = '201*****' # 对应写入你自己的教务账号
user_password = '*****' # 对应写入你自己的教务密码
user_major='**'#写入你的专业
```
入口文件：main.py,直接运行即可。
>感谢前人写好的自动化登陆，让我的工作减少了很多。本项目主要基于最近颁发的保研课程文件进行自动核算分数，目前可以用于交运各个专业，其他专业需要将文件格式改为交运的文件格式。可以用于各个年级查询。
---
>今后有空将会继续做一些可视化