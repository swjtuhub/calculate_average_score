#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
自动登陆教务网，计算保研分数，以交运公布的保研文件为例。
login.py:登陆教务网，爬取分数并保存文件，原作者SSSimon Yang，稍作修改后使用
config：配置文件，包括百度API，学号，密码，专业
本项目完全本地运行，无泄漏密码风险,低年级同学也可以查看自己的情况
@author:chenyue
@e-mail:cchenyuee@outlook.com
'''

import login
import pandas as pd
import config
import heapq

login.get_score()
csv_origin=pd.read_excel('2021届交通运输与物流学院免研课程公示版.xlsx',usecols=[1,3,4,5,7,9,12])
csv_origin.columns=['major','course_num','course_name','type','yes_or_no','group','select']
csv=csv_origin.iloc[1:]
logistic_engineering_required=csv[(csv['major']==config.user_major) & (csv['yes_or_no']=='是') & (csv['type']=='必')]

score=pd.read_excel('score.xlsx')

score_1=score[score.iloc[:,9]!='--']
course_get_num=score_1.iloc[:,2].tolist()
print ('你还有以下必修课未有得分:')
for i in range(len(logistic_engineering_required.index)):
    if logistic_engineering_required.iloc[i,1] not in course_get_num:
        print (logistic_engineering_required.iloc[i,2])
t=0
avg=0
for i in range(len(logistic_engineering_required.index)):
    if logistic_engineering_required.iloc[i,1] in course_get_num:
        t=t+1
        a=score[score.iloc[:,2]==logistic_engineering_required.iloc[i,1]].index.tolist()
        b=score.iloc[a[0],9]
        avg=avg+float(b)
print ('你一共完成了'+str(t)+'门必修课，')
print ('必修课平均分为:'+str(avg/t))

cal_elective_score=[]
logistic_engineering_elective=csv[(csv['major']==config.user_major) & (csv['yes_or_no']=='是') & (csv['type']=='限')]
groups=set(logistic_engineering_elective.iloc[:,5])

for i in groups:
    ran=logistic_engineering_elective[logistic_engineering_elective.iloc[:,5]==i].index.tolist()
    now_scores=[]
    for j in range(len(ran)):
        now_scores_num=(csv_origin.iloc[ran[j], 1])
        a = score[score.iloc[:, 2] == now_scores_num].index.tolist()
        b = score.iloc[a[0], 9]
        if b=='--':
            b=0
        now_scores.append(float(b))
    x = int(str(csv_origin.iloc[ran[0], 6])[-1])
    re = heapq.nlargest(x, now_scores)
    for k in re:
        cal_elective_score.append(k)
if 0 in cal_elective_score:
    print ('你还有选修课没有修完')
print ('您保研课一共计入'+str(len(cal_elective_score)+t)+'门课')
print ('总计均分为：'+str((avg+sum(cal_elective_score))/(t+len(cal_elective_score))))


